The following screenshots are supplied in the zip archive:

- bucket_created: Created S3 Bucket "bluecipher-website"
- files_uploaded: Website files loaded into bucket_created
- bucket_policy_defined: Enabled public access and defined bucket bucket_policy_defined
- website_hosted: Result od static website hostong configuration for bucket
- cloudfront_created: Created cloudfront distribution
- website_hosted: Final Result

The Cloudfront URL is http://d207b96tm0u6gx.cloudfront.net/index.html